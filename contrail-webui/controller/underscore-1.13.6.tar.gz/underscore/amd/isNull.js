define(function () {

  // Is a given value equal to null?
  function isNull(obj) {
    return obj === null;
  }

  return isNull;

});
