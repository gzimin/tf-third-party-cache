// Is a given value equal to null?
export default function isNull(obj) {
  return obj === null;
}
