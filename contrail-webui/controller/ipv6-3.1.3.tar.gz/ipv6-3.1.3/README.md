## DEPRECATED

This module has been renamed to
[ip-address](https://www.npmjs.com/package/ip-address).
