// 'some' - Promise extension
//
// promise.some(fn[, thisArg])
//
// Promise aware some for array-like results

"use strict";

require("./_array")("some", require("../array/some"));
