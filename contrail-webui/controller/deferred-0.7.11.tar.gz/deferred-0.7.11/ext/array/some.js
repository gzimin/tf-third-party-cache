// Promise aware Array's some

"use strict";

module.exports = require("../../lib/some-every")(true);
