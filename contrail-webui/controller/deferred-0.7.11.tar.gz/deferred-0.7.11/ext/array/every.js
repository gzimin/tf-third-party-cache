// Promise aware Array's every

"use strict";

module.exports = require("../../lib/some-every")(false);
