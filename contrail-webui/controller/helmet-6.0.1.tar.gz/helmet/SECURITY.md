# Security issue reporting & disclosure process

If you feel you have found a security issue or concern with Helmet, please reach out to the maintainers.

Email Evan Hahn at <me@evanhahn.com> or Adam Baldwin at <adam@npmjs.com>.

We will try to communicate in a timely manner and address your concerns.
